document.addEventListener("DOMContentLoaded", function() {
    // Tìm tất cả các form trên trang
    const forms = document.querySelectorAll("form");

    // Lặp qua từng form và gán sự kiện ngăn submit khi nhấn Enter
    forms.forEach(function(form) {
        const inputs = form.querySelectorAll("input");
        
        inputs.forEach(function(input) {
            input.addEventListener("keydown", function(event) {
                if (event.key === "Enter") {
                    event.preventDefault(); // Ngăn submit form khi nhấn Enter
                }
            });
        });
    });
});