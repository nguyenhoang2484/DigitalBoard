<!-- <h3>Thông tin Công tác / Business Register </h3> -->
<style type="text/css">
    table.business tr td {
        padding: 5px;
    }

    /* Căn chỉnh footer luôn ở đáy */
    html,
    body {
        height: 100%;
        margin: 0;
    }
</style>

<body>
    <div class="wrapper">
        <div class="wrapper">
            <div class="container">
                <div class="col-10 col-md-8 col-lg-6 col-xl-5">
                    <form action="pages/processbusiness.php" method="POST" id="businessForm">
                        <div class="table-responsive-sm">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr class="text-center bg-info text-white">
                                        <td colspan="2" class="fw-bold"
                                            style="text-align: center;background-color: lightseagreen;">
                                            BUSINESS</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong>Name</strong></td>
                                        <td><input type="text" class="form-control" name="Name" required></td>
                                    </tr>
                                    <tr>
                                        <td><strong>From Date</strong></td>
                                        <td><input type="date" class="form-control" name="FromDate" required></td>
                                    </tr>
                                    <tr>
                                        <td><strong>To Date</strong></td>
                                        <td><input type="date" class="form-control" name="ToDate" required></td>
                                    </tr>
                                    <tr>
                                        <td><strong>From Time</strong></td>
                                        <td><input type="time" class="form-control" name="FromTime" required></td>
                                    </tr>
                                    <tr>
                                        <td><strong>To Time</strong></td>
                                        <td><input type="time" class="form-control" name="ToTime" required></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Content</strong></td>
                                        <td><input type="text" class="form-control" name="Content" required></td>
                                    </tr>
                                    <tr class="text-center">
                                        <td colspan="2"><button type="submit" class="btn btn-primary"
                                                name="businessadd">Đăng ký /
                                                Register</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>



                <script src="js/preventEnterSubmit.js"></script>
                <?php
                $sql_lietke_business = "SELECT * FROM tbl_business ORDER BY B_UpdateTime ASC;";
                $query_lietke_business = mysqli_query($mysqli, $sql_lietke_business);
                $sql_lietke_business_updatetime = "SELECT * FROM tbl_business ORDER BY B_UpdateTime DESC LIMIT 1;";
                $query_lietke_business_updatetime = mysqli_query($mysqli, $sql_lietke_business_updatetime);
                $row_business_updatetime = mysqli_fetch_array($query_lietke_business_updatetime);
                ?>
                <div class="mt-3">
                    <table class="table-bordered table-striped table-hover table-sm"
                        style="table-layout: fixed; width: 100%;">
                        <h3>Recently business</h3>
                        <p>
                            <?php
                            if ($row_business_updatetime) {
                                echo 'Update Time: ' . $row_business_updatetime['B_UpdateTime'];
                            } else {
                                echo 'No recent updates found.';
                            }
                            ?>
                        </p>
                        <tr class=" text-center bg-body-secondary">
                            <th style="width: 3%;">ID</th>
                            <th style="width: 20%;">Name</th>
                            <th style="width: 8%;">Date From</th>
                            <th style="width: 8%;">Date To</th>
                            <th style="width: 8%;">Time From</th>
                            <th style="width: 8%;">Time To</th>
                            <th style="width: auto;">Business</th>
                            <th style="width: 10%;">Modify</th>
                        </tr>
                        <?php
                        $i = 0;
                        date_default_timezone_set('Asia/Ho_Chi_Minh'); // Thiết lập múi giờ
                        $currentDateTime = date('Y-m-d H:i:s'); // Lấy ngày giờ hiện tại
                        while ($row = mysqli_fetch_array($query_lietke_business)) {
                            $i++;
                            $dateFromTime = $row['D_From'] . ' ' . $row['T_From'];
                            $dateToTime = $row['D_To'] . ' ' . $row['T_To'];

                            // Kiểm tra điều kiện để xác định màu sắc cho dòng
                            $bgColor = '';
                            if (!empty($row['B_Name']) && !empty($row['D_From']) && !empty($row['T_From']) && !empty($row['B_Type'])) {
                                if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffeb99'; // Light Yellow cho dòng đang diễn ra
                                } elseif ($dateToTime >= $currentDateTime) {
                                    $bgColor = '#b3e0ff'; // Light Blue cho dòng còn hiệu lực
                                } else {
                                    $bgColor = '#ffcccc'; // Light Red cho dòng đã hết hạn
                                }
                            } else {
                                $bgColor = '#d9d9d9'; // Light Gray cho dòng chưa có thông tin
                            }
                            ?>
                            <tr style="height: 40px; background-color: <?php echo $bgColor; ?>;">
                                <th class="text-center"><?php echo $i ?></th>
                                <td style="padding-left: 5px;"><?php echo $row['B_Name'] ?></td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("Y-M-d", strtotime($row['D_From'])); ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("Y-M-d", strtotime($row['D_To'])); ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("H:i", strtotime($row['T_From'])) ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("H:i", strtotime($row['T_To'])) ?>
                                </td>
                                <td style="padding-left: 5px;"><?php echo $row['B_Type'] ?></td>
                                <td>
                                    <a style="padding-left: 5px; text-align: center;"
                                        href="pages/processbusiness.php?idroom=<?php echo $row['id'] ?>"> Delete </a> | <a
                                        href="pages/modifybusiness.php?idroom=<?php echo $row['id'] ?>"> Update </a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                </div>
                <p class="mb-3 mt-3"><strong>Note:</strong>
                    <span style="background-color: #b3e0ff; display: inline-block; padding: 3px;">Upcoming</span>
                    <span style="background-color: #ffeb99; display: inline-block; padding: 3px;">Ongoing</span>
                    <!-- <span style="background-color: #ffcccc; display: inline-block; padding: 3px;">Past events</span> -->
                </p>
            </div>
        </div>
    </div>
</body>