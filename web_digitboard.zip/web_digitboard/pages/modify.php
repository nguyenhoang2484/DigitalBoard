<?php include_once("../admincp/config/config.php");
$sql_sua_room = "SELECT * FROM tbl_room WHERE id = '$_GET[idroom]' LIMIT 1";
$query_sua_room = mysqli_query($mysqli, $sql_sua_room);
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Modify Meeting Room</title>
	<link href="../css/bootstrap.css" rel="stylesheet">
</head>

<body>
	<div class="container mt-1 mb-5">
		<div class="col-10 col-md-8 col-lg-6 col-xl-5">
			<!-- <h3 class="text-center mb-4">Modify Meeting Room Information</h3> -->
			<form method="POST" action="process.php?idroom=<?php echo $_GET['idroom'] ?>">
				<div class="table-responsive">
					<table class="table table-bordered table-striped">
						<?php while ($dong = mysqli_fetch_array($query_sua_room)) { ?>
							<thead>
								<tr class="text-center bg-info text-white">
									<td colspan="2" class="fw-bold"
										style="text-align: center;background-color: lightcoral;">UPDATE MEETING ROOM</td>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><strong>Room Name</strong></td>
									<td><input type="text" class="form-control" value="<?php echo $dong['R_Name'] ?>"
											name="Name"></td>
								</tr>
								<tr>
									<td><strong>From Date</strong></td>
									<td><input type="date" class="form-control" value="<?php echo $dong['RD_From'] ?>"
											name="FromDate"></td>
								</tr>
								<tr>
									<td><strong>To Date</strong></td>
									<td><input type="date" class="form-control" value="<?php echo $dong['RD_To'] ?>"
											name="ToDate"></td>
								</tr>
								<tr>
									<td><strong>From Time</strong></td>
									<td><input type="time" class="form-control" value="<?php echo $dong['RT_From'] ?>"
											name="FromTime"></td>
								</tr>
								<tr>
									<td><strong>To Time</strong></td>
									<td><input type="time" class="form-control" value="<?php echo $dong['RT_To'] ?>"
											name="ToTime"></td>
								</tr>
								<tr>
									<td><strong>Content</strong></td>
									<td><input type="text" class="form-control" value="<?php echo $dong['RType'] ?>"
											name="Content"></td>
								</tr>
								<tr>
									<td colspan="2" class="text-center">
										<button type="submit" name="roomupdate" class="btn btn-primary">Update</button>
										<a href="../index.php?quanly=room&query=add" class="btn btn-secondary">Go Back</a>
									</td>
								</tr>
							</tbody>
						<?php } ?>
					</table>
				</div>
			</form>
		</div>
		<?php
		$sql_lietke_room = "SELECT * FROM tbl_room ORDER BY R_UpdateTime ASC;";
		$query_lietke_room = mysqli_query($mysqli, $sql_lietke_room);
		$sql_lietke_room_updatetime = "SELECT * FROM tbl_room ORDER BY R_UpdateTime DESC LIMIT 1;";
		$query_lietke_room_updatetime = mysqli_query($mysqli, $sql_lietke_room_updatetime);
		$row_room_updatetime = mysqli_fetch_array($query_lietke_room_updatetime);
		?>
		<div class="mt-3">
			<table class="table-bordered table-striped table-hover table-sm">
				<h3>Recently Meeting Room</h3>
				<p>
					<?php
					if ($row_room_updatetime) {
						echo 'Update Time: ' . $row_room_updatetime['R_UpdateTime'];
					} else {
						echo 'No recent updates found.';
					}
					?>
				</p>

				<tr class=" text-center bg-body-secondary">
					<th style="width: 3%;">ID</th>
					<th style="width: 20%;">Room Register</th>
					<th style="width: 8%;">Date From</th>
					<th style="width: 8%;">Date To</th>
					<th style="width: 8%;">Time From</th>
					<th style="width: 8%;">Time To</th>
					<th style="width: 32%;">User</th>
				</tr>
				<?php
				$i = 0;
				date_default_timezone_set('Asia/Ho_Chi_Minh'); // Thiết lập múi giờ
				$currentDateTime = date('Y-m-d H:i:s'); // Lấy ngày giờ hiện tại
				while ($row = mysqli_fetch_array($query_lietke_room)) {
					$i++;
					$dateFromTime = $row['RD_From'] . ' ' . $row['RT_From'];
					$dateToTime = $row['RD_To'] . ' ' . $row['RT_To'];

					// Kiểm tra điều kiện để xác định màu sắc cho dòng
					$bgColor = '';
					if (!empty($row['R_Name']) && !empty($row['RD_From']) && !empty($row['RT_From']) && !empty($row['RType'])) {
						if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
							$bgColor = '#ffeb99'; // Light Yellow cho dòng đang diễn ra
						} elseif ($dateToTime >= $currentDateTime) {
							$bgColor = '#b3e0ff'; // Light Blue cho dòng còn hiệu lực
						} else {
							$bgColor = '#ffcccc'; // Light Red cho dòng đã hết hạn
						}
					} else {
						$bgColor = '#d9d9d9'; // Light Gray cho dòng chưa có thông tin
					}
					?>
					<tr style="height: 40px; background-color: <?php echo $bgColor; ?>;">
						<th class="text-center"><?php echo $i ?></th>
						<td style="padding-left: 5px;"><?php echo $row['R_Name'] ?></td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("Y-M-d", strtotime($row['RD_From'])); ?>
						</td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("Y-M-d", strtotime($row['RD_To'])); ?>
						</td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("H:i", strtotime($row['RT_From'])) ?>
						</td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("H:i", strtotime($row['RT_To'])) ?>
						</td>
						<td style="padding-left: 5px;"><?php echo $row['RType'] ?></td>
					</tr>
					<?php
				}
				?>
			</table>
		</div>
	</div>

	<script src="../js/bootstrap.js"></script>
</body>

</html>