<body>
    <div class="container copy-right">
        <p class="text-center text-white">Digital Board by Nguyen Hoang - 2024</p>
    </div>
</body>