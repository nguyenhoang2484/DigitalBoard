<!-- <h3>Thông tin Phòng họp / Meeting Room Register </h3> -->
<?php
$sql_name_room = "SELECT roomname FROM tbl_roomname ORDER BY idroom ASC";
$query_name_room = mysqli_query($mysqli, $sql_name_room);
// $row_room_updatetime = mysqli_fetch_array($query_lietke_room_updatetime);
?>
<style type="text/css">
    table.room tr td {
        padding: 5px;
    }
</style>

<body>
    <div class="wrapper">
        <div class="container">
            <div class="col-10 col-md-8 col-lg-6 col-xl-5">
                <form method="POST" action="pages/process.php" id="roomForm">
                    <div class="table-responsive-sm">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr class="text-center bg-info text-white">
                                    <td colspan="2" class="fw-bold"
                                        style="text-align: center;background-color: lightcoral;">MEETING ROOM</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Name</strong></td>
                                    <td>
                                        <select name="Name" style="width: auto; height: 37.5px;">
                                            <?php
                                            // Kiểm tra nếu có kết quả
                                            if ($query_name_room->num_rows > 0) {
                                                // Duyệt qua các kết quả và tạo các tùy chọn cho drop-down list
                                                while ($row = $query_name_room->fetch_assoc()) {
                                                    echo "<option value='" . $row['roomname'] . "'>" . $row['roomname'] . "</option>";
                                                }
                                            } else {
                                                echo "<option value=''>No rooms available</option>";
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>From Date</strong></td>
                                    <td><input type="date" class="form-control" name="FromDate" required></td>
                                </tr>
                                <tr>
                                    <td><strong>To Date</strong></td>
                                    <td><input type="date" class="form-control" name="ToDate" required></td>
                                </tr>
                                <tr>
                                    <td><strong>From Time</strong></td>
                                    <td><input type="time" class="form-control" name="FromTime" required></td>
                                </tr>
                                <tr>
                                    <td><strong>To Time</strong></td>
                                    <td><input type="time" class="form-control" name="ToTime" required></td>
                                </tr>
                                <tr>
                                    <td><strong>User</strong></td>
                                    <td><input type="text" class="form-control" name="Content" required></td>

                                </tr>
                                <tr class="text-center">
                                    <td colspan="2">
                                        <button type="submit" class="btn btn-primary" name="roominfoadd">Đăng ký /
                                            Register</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
            <script src="js/preventEnterSubmit.js"></script>
            <?php
            $sql_lietke_room = "SELECT * FROM tbl_room ORDER BY R_UpdateTime ASC;";
            $query_lietke_room = mysqli_query($mysqli, $sql_lietke_room);
            $sql_lietke_room_updatetime = "SELECT * FROM tbl_room ORDER BY R_UpdateTime DESC LIMIT 1;";
            $query_lietke_room_updatetime = mysqli_query($mysqli, $sql_lietke_room_updatetime);
            $row_room_updatetime = mysqli_fetch_array($query_lietke_room_updatetime);
            ?>
            <div class="mt-3">
                <table class="table-bordered table-striped table-hover table-sm"
                    style="table-layout: fixed; width: 100%;">
                    <h3>Recently Meeting Room</h3>
                    <p>
                        <?php
                        if ($row_room_updatetime) {
                            echo 'Update Time: ' . $row_room_updatetime['R_UpdateTime'];
                        } else {
                            echo 'No recent updates found.';
                        }
                        ?>
                    </p>

                    <tr class=" text-center bg-body-secondary">
                        <th style="width: 3%;">ID</th>
                        <th style="width: 20%;">Room Register</th>
                        <th style="width: 8%;">Date From</th>
                        <th style="width: 8%;">Date To</th>
                        <th style="width: 8%;">Time From</th>
                        <th style="width: 8%;">Time To</th>
                        <th style="width: auto;">User</th>
                        <th style="width: 10%;">Modify</th>
                    </tr>
                    <?php
                    $i = 0;
                    date_default_timezone_set('Asia/Ho_Chi_Minh'); // Thiết lập múi giờ
                    $currentDateTime = date('Y-m-d H:i:s'); // Lấy ngày giờ hiện tại
                    while ($row = mysqli_fetch_array($query_lietke_room)) {
                        $i++;
                        $dateFromTime = $row['RD_From'] . ' ' . $row['RT_From'];
                        $dateToTime = $row['RD_To'] . ' ' . $row['RT_To'];

                        // Kiểm tra điều kiện để xác định màu sắc cho dòng
                        $bgColor = '';
                        if (!empty($row['R_Name']) && !empty($row['RD_From']) && !empty($row['RT_From']) && !empty($row['RType'])) {
                            if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
                                $bgColor = '#ffeb99'; // Light Yellow cho dòng đang diễn ra
                            } elseif ($dateToTime >= $currentDateTime) {
                                $bgColor = '#b3e0ff'; // Light Blue cho dòng còn hiệu lực
                            } else {
                                $bgColor = '#ffcccc'; // Light Red cho dòng đã hết hạn
                            }
                        } else {
                            $bgColor = '#d9d9d9'; // Light Gray cho dòng chưa có thông tin
                        }
                        ?>
                        <tr style="height: 40px; background-color: <?php echo $bgColor; ?>;">
                            <th class="text-center"><?php echo $i ?></th>
                            <td style="padding-left: 5px;"><?php echo $row['R_Name'] ?></td>
                            <td style="padding-left: 5px; text-align: center;">
                                <?php echo date("Y-M-d", strtotime($row['RD_From'])); ?>
                            </td>
                            <td style="padding-left: 5px; text-align: center;">
                                <?php echo date("Y-M-d", strtotime($row['RD_To'])); ?>
                            </td>
                            <td style="padding-left: 5px; text-align: center;">
                                <?php echo date("H:i", strtotime($row['RT_From'])) ?>
                            </td>
                            <td style="padding-left: 5px; text-align: center;">
                                <?php echo date("H:i", strtotime($row['RT_To'])) ?>
                            </td>
                            <td style="padding-left: 5px;"><?php echo $row['RType'] ?></td>
                            <td>
                                <a style="padding-left: 5px; text-align: center;"
                                    href="pages/process.php?idroom=<?php echo $row['id'] ?>"> Delete </a> | <a
                                    href="pages/modify.php?idroom=<?php echo $row['id'] ?>"> Update </a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
            </div>
            <p class="mb-3 mt-3"><strong>Note:</strong>
                <span style="background-color: #b3e0ff; display: inline-block; padding: 3px;">Upcoming</span>
                <span style="background-color: #ffeb99; display: inline-block; padding: 3px;">Ongoing</span>
                <!-- <span style="background-color: #ffcccc; display: inline-block; padding: 3px;">Past events</span> -->
            </p>
        </div>
    </div>
</body>