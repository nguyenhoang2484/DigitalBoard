<?php
$today = date('Y-m-d');

// Kiểm tra nếu bảng có dữ liệu chưa
$result = $mysqli->query("SELECT last_run FROM tbl_archive_log LIMIT 1");
$row = $result->fetch_assoc();

if ($row && $row['last_run'] == $today) {
    $mysqli->close();
    return; // Nếu đã chạy hôm nay, thoát
}

// Di chuyển dữ liệu cần thiết
$mysqli->query("INSERT INTO tbl_schedule_archive SELECT * FROM tbl_schedule WHERE D_To < CURDATE()");
$mysqli->query("DELETE FROM tbl_schedule WHERE D_To < CURDATE()");
$mysqli->query("INSERT INTO tbl_room_archive SELECT * FROM tbl_room WHERE RD_To < CURDATE()");
$mysqli->query("DELETE FROM tbl_room WHERE RD_To < CURDATE()");
$mysqli->query("INSERT INTO tbl_business_archive SELECT * FROM tbl_business WHERE D_To < CURDATE()");
$mysqli->query("DELETE FROM tbl_business WHERE D_To < CURDATE()");

// Cập nhật timestamp: chỉ có 1 dòng duy nhất
$mysqli->query("INSERT INTO tbl_archive_log (id, last_run) VALUES (1, '$today') ON DUPLICATE KEY UPDATE last_run = '$today'");

// Đóng kết nối
$mysqli->close();
?>