<?php
//Config // include("../admincp/config/config.php");
$sql_lietke_room = "SELECT * FROM tbl_room ORDER BY R_Name ASC, RD_From ASC, RT_From ASC;";
$query_lietke_room = mysqli_query($mysqli, $sql_lietke_room);
$roomData = [];
while
($row = mysqli_fetch_assoc($query_lietke_room)) {
    $roomData[] = $row;
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meeting Room Timeline</title>
    <script src="../fullcalendar/dist/index.global.js"></script>
</head>
<div class="container">
    <dov>
        <h3 class="mb-2">Meeting Room TimeLine</h3>

        <div id="calendar"></div>

        <script>
            // chuẩn bị dữ liệu resource (phòng)
            var resourcesData = <?php
            $rooms = [];
            foreach ($roomData as $r) {
                $rooms[$r['R_Name']] = ['id' => $r['R_Name'], 'title' => $r['R_Name']];
            }
            echo json_encode(array_values($rooms));
            ?>;

            // chuẩn bị dữ liệu events
            var eventsData = <?php
            $events = [];
            foreach ($roomData as $r) {
                $events[] = [
                    'id' => $r['id'],
                    'resourceId' => $r['R_Name'],
                    'title' => $r['RType'] . " (" . $r['R_Name'] . ")",
                    'start' => $r['RD_From'] . "T" . $r['RT_From'],
                    'end' => $r['RD_To'] . "T" . $r['RT_To']
                ];
            }
            echo json_encode($events);
            ?>;

            document.addEventListener('DOMContentLoaded', function () {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    schedulerLicenseKey: 'GPL-My-Project-Is-Open-Source',
                    initialView: 'resourceTimelineDay',
                    resourceAreaHeaderContent: 'Meeting Rooms',
                    resources: resourcesData,
                    events: eventsData,
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'resourceTimelineDay,resourceTimelineWeek,resourceTimelineMonth,listMonth'
                    },
                    slotMinTime: "06:00:00",   // bắt đầu từ 7 giờ sáng
                    slotMaxTime: "19:00:00",   // kết thúc ở 7 giờ tối
                    height: 'auto',
                    hiddenDays: [0], // ẩn Chủ Nhật
                    businessHours: {
                        daysOfWeek: [1, 2, 3, 4, 5, 6], // Thứ 2 -> Thứ 6
                        startTime: '07:30',          // bắt đầu làm việc
                        endTime: '16:30'             // kết thúc làm việc
                    },
                    eventDidMount: function (info) {
                        // gắn tooltip mặc định (trình duyệt sẽ tự hiện khi hover)
                        info.el.setAttribute("title", info.event.title);
                    }
                });

                calendar.render();
            });
        </script>
        </body>
        <div> <a href="../index.php" class="btn btn-sm btn-primary my-2" style="margin-left:0px;">
                Back
            </a>
        </div>
</div>

</html>