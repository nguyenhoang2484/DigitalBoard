<?php
// $sql_lietke_room = "SELECT * FROM tbl_room ORDER BY RD_From, R_Name ASC;";
$sql_lietke_room = "SELECT * FROM tbl_room ORDER BY R_Name ASC, RD_From ASC, RT_From ASC;";
$query_lietke_room = mysqli_query($mysqli, $sql_lietke_room);
$sql_lietke_room_updatetime = "SELECT * FROM tbl_room ORDER BY R_UpdateTime DESC LIMIT 1;";
$query_lietke_room_updatetime = mysqli_query($mysqli, $sql_lietke_room_updatetime);
$row_room_updatetime = mysqli_fetch_array($query_lietke_room_updatetime);
?>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        @media (max-width: 768px) {
            table.table-sm {
                font-size: 12px;
                table-layout: fixed;
            }

            .table-sm th,
            .table-sm td {
                padding: 0.3rem;
                word-wrap: break-word;
            }

            th:nth-child(3),
            th:nth-child(4),
            th:nth-child(5),
            th:nth-child(6),
            td:nth-child(3),
            td:nth-child(4),
            td:nth-child(5),
            td:nth-child(6) {
                width: 17% !important;
            }

            th:nth-child(7),
            td:nth-child(7) {
                width: auto !important;
            }

            span {
                display: block;
                margin-top: 0.5rem;
            }

            i.fa-solid,
            i.fa-calendar-days,
            i.fa-handshake {
                font-size: 20px !important;
            }
        }
    </style>

</head>

<body>
    <div class="wrapper">
        <div class="container">
            <div class="col-md-12">
                <div class="mt-3 mb-3 table-responsive">
                    <table class="table-bordered table-striped table-hover table-sm"
                        style="table-layout: fixed; width: 100%;">
                        <span><i class="fa-solid fa-user-group" style="font-size: 30px; color:lightcoral"></i> </span>
                        <span style="font-weight:bolder; font-size: 20px;">Meeting Room</span><span
                            style=" font-style: italic;">
                            - Update Time:
                            <?php echo $row_room_updatetime ? $row_room_updatetime['R_UpdateTime'] : 'No recent updates found.'; ?>

                        </span>
                        <a href="index.php?quanly=room&query=view" class="btn btn-sm btn-primary mb-2"
                            style="margin-left:10px;">
                            View Timeline
                        </a>
                        <tr style=" background-color: lightcoral;" class="text-center">
                            <th style="width: 7%;">ID</th>
                            <th style="width: auto;">Room Register</th>
                            <th style="width: auto;">Date From</th>
                            <th style="width: auto;">Date To</th>
                            <th style="width: auto;">Time From</th>
                            <th style="width: auto;">Time To</th>
                            <th style="width: 30%;">User</th>
                        </tr>
                        <?php
                        $i = 0;
                        date_default_timezone_set('Asia/Ho_Chi_Minh');
                        $currentDateTime = date('Y-m-d H:i:s');
                        $roomData = [];
                        while ($row = mysqli_fetch_assoc($query_lietke_room)) {
                            $roomData[] = $row;
                        }
                        $roomCounts = [];
                        $prevRoom = '';
                        $count = 0;
                        foreach ($roomData as $index => $row) {
                            if ($row['R_Name'] !== $prevRoom) {
                                if ($count > 0) {
                                    $roomCounts[$prevRoom][] = $count;
                                }
                                $prevRoom = $row['R_Name'];
                                $count = 1;
                            } else {
                                $count++;
                            }
                        }
                        if ($count > 0) {
                            $roomCounts[$prevRoom][] = $count;
                        }

                        $i = 0;
                        $prevRoom = '';
                        $printCount = 0;
                        foreach ($roomData as $row) {
                            $i++;
                            $dateFromTime = $row['RD_From'] . ' ' . $row['RT_From'];
                            $dateToTime = $row['RD_To'] . ' ' . $row['RT_To'];

                            $bgColor = '';
                            $fontWeight = 'normal';
                            if (!empty($row['R_Name']) && !empty($row['RD_From']) && !empty($row['RT_From']) && !empty($row['RType'])) {
                                if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffeb99';
                                    $fontWeight = 'bold';
                                } elseif ($dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffffff';
                                } else {
                                    $bgColor = '#ffcccc';
                                }
                            } else {
                                $bgColor = '#d9d9d9';
                            }

                            echo "<tr style=\"height: 40px; font-weight: {$fontWeight};\">";
                            echo "<th class=\"text-center\">{$i}</th>";

                            if ($row['R_Name'] !== $prevRoom) {
                                $rowspan = $roomCounts[$row['R_Name']][0];
                                echo "<td rowspan=\"{$rowspan}\" style=\"padding-left: 5px; vertical-align: middle;\">{$row['R_Name']}</td>";
                                $printCount = $rowspan - 1;
                                array_shift($roomCounts[$row['R_Name']]);
                            } else {
                                if ($printCount > 0) {
                                    $printCount--;
                                }
                            }

                            echo "<td style=\"text-align:center;background-color: {$bgColor};\">" . date("M-d", strtotime($row['RD_From'])) . "</td>";
                            echo "<td style=\"text-align:center;background-color: {$bgColor};\">" . date("M-d", strtotime($row['RD_To'])) . "</td>";
                            echo "<td style=\"text-align:center;background-color: {$bgColor};\">" . date("H:i", strtotime($row['RT_From'])) . "</td>";
                            echo "<td style=\"text-align:center;background-color: {$bgColor};\">" . date("H:i", strtotime($row['RT_To'])) . "</td>";
                            echo "<td style=\"padding-left: 5px;background-color: {$bgColor};\">{$row['RType']}</td>";
                            echo "</tr>";

                            $prevRoom = $row['R_Name'];
                        }
                        ?>
                    </table>
                </div>
                <?php
                $sql_lietke_schedule = "SELECT * FROM tbl_schedule ORDER BY D_From ASC;";
                $query_lietke_schedule = mysqli_query($mysqli, $sql_lietke_schedule);
                $sql_schedule_updatetime = "SELECT * FROM tbl_schedule ORDER BY S_UpdateTime DESC LIMIT 1;";
                $query_schedule_updatetime = mysqli_query($mysqli, $sql_schedule_updatetime);
                $row_schedule_updatetime = mysqli_fetch_array($query_schedule_updatetime);
                ?>
                <div class="mt-3 table-responsive">
                    <table class="table-bordered table-striped table-hover table-sm"
                        style="table-layout: fixed; width: 100%;">
                        <span><i class="fa-solid fa-calendar-days" style="font-size: 30px; color:lightskyblue"></i>
                        </span>
                        <span style="font-weight:bolder; font-size: 20px;">Schedule</span><span
                            style="font-style: italic;">
                            - Update Time: <?php
                            if ($row_schedule_updatetime) {
                                echo $row_schedule_updatetime['S_UpdateTime'];
                            } else {
                                echo 'No recent updates found.';
                            }
                            ?></span>
                        <tr class="text-center" style="background-color: lightskyblue;">
                            <th style="width: 7%;">ID</th>
                            <th style="width: auto;">Name</th>
                            <th style="width: auto;">Date From</th>
                            <th style="width: auto;">Date To</th>
                            <th style="width: auto;">Time From</th>
                            <th style="width: auto;">Time To</th>
                            <th style="width: 30%;">Content</th>
                        </tr>
                        <?php
                        $i = 0;
                        while ($row = mysqli_fetch_array($query_lietke_schedule)) {
                            $i++;
                            $dateFromTime = $row['D_From'] . ' ' . $row['T_From'];
                            $dateToTime = $row['D_To'] . ' ' . $row['T_To'];
                            // Kiểm tra điều kiện để xác định màu sắc cho dòng
                            $bgColor = '';
                            $fontWeight = 'normal';
                            if (!empty($row['S_Name']) && !empty($row['D_From']) && !empty($row['T_From']) && !empty($row['S_Type'])) {
                                if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffeb99'; // Light Yellow cho dòng đang diễn ra
                                    $fontWeight = 'bold';
                                } elseif ($dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffffff'; // Light Blue cho dòng còn hiệu lực
                                } else {
                                    $bgColor = '#ffcccc'; // Light Red cho dòng đã hết hạn
                                }
                            } else {
                                $bgColor = '#d9d9d9'; // Light Gray cho dòng chưa có thông tin
                            }
                            ?>
                            <tr
                                style="height: 40px; font-weight: <?php echo $fontWeight; ?>; background-color: <?php echo $bgColor; ?>;">
                                <th class="text-center"><?php echo $i ?></th>
                                <td style="padding-left: 5px;"><?php echo $row['S_Name'] ?></td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("M-d", strtotime($row['D_From'])); ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("M-d", strtotime($row['D_To'])); ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("H:i", strtotime($row['T_From'])) ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("H:i", strtotime($row['T_To'])) ?>
                                </td>
                                <td style="padding-left: 5px;"><?php echo $row['S_Type'] ?></td>
                            </tr>
                            <?php
                        }
                        ?>

                    </table>
                </div>
                <?php
                $sql_lietke_business = "SELECT * FROM tbl_business ORDER BY D_From ASC;";
                $query_lietke_business = mysqli_query($mysqli, $sql_lietke_business);
                $sql_business_updatetime = "SELECT * FROM tbl_business ORDER BY B_UpdateTime DESC LIMIT 1;";
                $query_business_updatetime = mysqli_query($mysqli, $sql_business_updatetime);
                $row_business_updatetime = mysqli_fetch_array($query_business_updatetime);
                ?>
                <div class="mt-3 table-responsive">
                    <table class="table-bordered table-striped table-hover table-sm"
                        style="table-layout: fixed; width: 100%;">
                        <span><i class="fa-regular fa-handshake" style="font-size: 30px; color: lightseagreen;"></i>
                        </span>
                        <span style="font-weight:bolder; font-size: 20px;">Business</span><span
                            style="font-style: italic;">
                            - Update Time: <?php
                            if ($row_business_updatetime) {
                                echo $row_business_updatetime['B_UpdateTime'];
                            } else {
                                echo 'No recent updates found.';
                            }
                            ?></span>
                        <tr style="background-color: lightseagreen;" class="text-center">
                            <th style="width: 7%;">ID</th>
                            <th style="width: auto;">Name</th>
                            <th style="width: auto;">Date From</th>
                            <th style="width: auto;">Date To</th>
                            <th style="width: auto;">Time From</th>
                            <th style="width: auto;">Time To</th>
                            <th style="width: 30%;">Content</th>
                        </tr>
                        <?php
                        $i = 0;
                        while ($row = mysqli_fetch_array($query_lietke_business)) {
                            $i++;
                            $dateFromTime = $row['D_From'] . ' ' . $row['T_From'];
                            $dateToTime = $row['D_To'] . ' ' . $row['T_To'];

                            // Kiểm tra điều kiện để xác định màu sắc cho dòng
                            $bgColor = '';
                            $fontWeight = 'normal';
                            if (!empty($row['B_Name']) && !empty($row['D_From']) && !empty($row['T_From']) && !empty($row['B_Type'])) {
                                if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffeb99'; // Light Yellow cho dòng đang diễn ra
                                    $fontWeight = 'bold';
                                } elseif ($dateToTime >= $currentDateTime) {
                                    $bgColor = '#ffffff'; // Light Blue cho dòng còn hiệu lựcb3e0ff
                                } else {
                                    $bgColor = '#ffcccc'; // Light Red cho dòng đã hết hạn
                                }
                            } else {
                                $bgColor = '#d9d9d9'; // Light Gray cho dòng chưa có thông tin
                            }
                            ?>
                            <tr
                                style="height: 40px; font-weight: <?php echo $fontWeight; ?>; background-color: <?php echo $bgColor; ?>;">
                                <th class="text-center"><?php echo $i ?></th>
                                <td style="padding-left: 5px;"><?php echo $row['B_Name'] ?></td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("M-d", strtotime($row['D_From'])); ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("M-d", strtotime($row['D_To'])); ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("H:i", strtotime($row['T_From'])) ?>
                                </td>
                                <td style="padding-left: 5px; text-align: center;">
                                    <?php echo date("H:i", strtotime($row['T_To'])) ?>
                                </td>
                                <td style="padding-left: 5px;"><?php echo $row['B_Type'] ?></td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                </div>
                <div class="row mb-3 mt-3">
                    <p><strong>Note:</strong>
                        <!-- <span style="background-color: #b3e0ff; display: inline-block; padding: 3px;">Upcoming</span> -->
                        <span style="background-color: #ffeb99; display: inline-block; padding: 3px;">Ongoing</span>
                        <span style="background-color: #ffcccc; display: inline-block; padding: 3px;">Past events</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>