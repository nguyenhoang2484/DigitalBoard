<?php
include_once("../admincp/config/config.php");

$Name = $_POST['Name'];
$FromDate = $_POST['FromDate'];
$ToDate = $_POST['ToDate'];
$FromTime = $_POST['FromTime'];
$ToTime = $_POST['ToTime'];
$Content = $_POST['Content'];

function showConflictList($result)
{
	echo "<div style='color: red; font-family: Arial; padding: 20px;'>";
	echo "<h3>❌ Có lịch trùng / Conflicting Schedules Detected:</h3><ul>";
	while ($row = $result->fetch_assoc()) {
		echo "<li>
            <strong>Tên phòng / Room:</strong> " . $row['R_Name'] . " | 
            <strong>Ngày / Date:</strong> " . $row['RD_From'] . " → " . $row['RD_To'] . " | 
            <strong>Giờ / Time:</strong> " . $row['RT_From'] . " → " . $row['RT_To'] . "
        </li>";
	}
	echo "</ul>";
	echo "<br><button onclick='history.back()' style='padding: 5px 10px; font-size: 14px;'>🔙 Quay lại / Go Back</button>";
	echo "</div>";
	exit();
}


if (isset($_POST['roominfoadd'])) {
	$newStart = $FromDate . ' ' . $FromTime;
	$newEnd = $ToDate . ' ' . $ToTime;

	$check_sql = "SELECT * FROM tbl_room 
        WHERE R_Name = ? 
        AND NOT (
            CONCAT(RD_To, ' ', RT_To) <= ? OR 
            CONCAT(RD_From, ' ', RT_From) >= ?
        )";
	$stmt = $mysqli->prepare($check_sql);
	$stmt->bind_param("sss", $Name, $newStart, $newEnd);
	$stmt->execute();
	$result = $stmt->get_result();

	if ($result->num_rows > 0) {
		showConflictList($result);
	}

	// Thêm nếu không bị trùng
	$sql_room_add = mysqli_query($mysqli, "INSERT INTO tbl_room(R_Name, RD_From, RD_To, RT_From, RT_To, RType) 
        VALUES ('$Name', '$FromDate', '$ToDate', '$FromTime', '$ToTime', '$Content')");
	header('Location:../index.php?quanly=room&query=add');

} elseif (isset($_POST['roomupdate'])) {
	$newStart = $FromDate . ' ' . $FromTime;
	$newEnd = $ToDate . ' ' . $ToTime;
	$idUpdate = $_GET['idroom'];

	$check_sql = "SELECT * FROM tbl_room 
        WHERE R_Name = ? 
        AND id != ? 
        AND NOT (
            CONCAT(RD_To, ' ', RT_To) <= ? OR 
            CONCAT(RD_From, ' ', RT_From) >= ?
        )";
	$stmt = $mysqli->prepare($check_sql);
	$stmt->bind_param("ssss", $Name, $idUpdate, $newStart, $newEnd);
	$stmt->execute();
	$result = $stmt->get_result();

	if ($result->num_rows > 0) {
		showConflictList($result);
	}

	// Cập nhật nếu không bị trùng
	$sql_modify = "UPDATE tbl_room SET 
        R_Name = '$Name', 
        RD_From = '$FromDate', 
        RD_To = '$ToDate',
        RT_From = '$FromTime', 
        RT_To = '$ToTime', 
        RType = '$Content' 
        WHERE id = '$idUpdate'";
	mysqli_query($mysqli, $sql_modify);
	header('Location:../index.php?quanly=room&query=add');

} else {
	// Xoá lịch
	$id = $_GET['idroom'];
	$sql_delete = "DELETE FROM tbl_room WHERE id='$id'";
	mysqli_query($mysqli, $sql_delete);
	header('Location:../index.php?quanly=room&query=add');
}
?>