<?php
include_once("../admincp/config/config.php");
$Name = $_POST['Name'];
$FromDate = $_POST['FromDate'];
$ToDate = $_POST['ToDate'];
$FromTime = $_POST['FromTime'];
$ToTime = $_POST['ToTime'];
$Content = $_POST['Content'];
if (isset($_POST['scheduleadd'])) {
	// echo $_POST['addroom']
	$sql_plan_add = mysqli_query($mysqli, "INSERT INTO tbl_schedule(S_Name,D_From,D_To,T_From,T_To,S_Type) VALUE('" . $Name . "','" . $FromDate . "','" . $ToDate . "','" . $FromTime . "','" . $ToTime . "','" . $Content . "')");
	header('Location:../index.php?quanly=schedule&query=add');
} elseif (isset($_POST['scheduleupdate'])) {
	//Modify
	$sql_modify = "UPDATE tbl_schedule SET S_Name ='" . $Name . "', D_From = '" . $FromDate . "',D_To = '" . $ToDate . "', T_From = '" . $FromTime . "',T_To = '" . $ToTime . "' ,S_Type = '" . $Content . "' WHERE id='" . $_GET['idroom'] . "'";
	mysqli_query($mysqli, $sql_modify);
	header('Location:../index.php?quanly=schedule&query=add');
	//Delete
} else {
	$id = $_GET['idroom'];
	$sql_delete = "DELETE FROM tbl_schedule WHERE id='" . $id . "'";
	mysqli_query($mysqli, $sql_delete);
	header('Location:../index.php?quanly=schedule&query=add');
}

?>