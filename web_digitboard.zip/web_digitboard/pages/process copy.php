<?php
include_once("../admincp/config/config.php");
$Name = $_POST['Name'];
$FromDate = $_POST['FromDate'];
$ToDate = $_POST['ToDate'];
$FromTime = $_POST['FromTime'];
$ToTime = $_POST['ToTime'];
$Content = $_POST['Content'];
if (isset($_POST['roominfoadd'])) {
	// echo $_POST['addroom']
	$sql_room_add = mysqli_query($mysqli, "INSERT INTO tbl_room(R_Name,RD_From,RD_To,RT_From,RT_To,RType) VALUE('" . $Name . "','" . $FromDate . "','" . $ToDate . "','" . $FromTime . "','" . $ToTime . "','" . $Content . "')");
	header('Location:../index.php?quanly=room&query=add');
} elseif (isset($_POST['roomupdate'])) {
	//Modify
	$sql_modify = "UPDATE tbl_room SET R_Name ='" . $Name . "', RD_From = '" . $FromDate . "',RD_To = '" . $ToDate . "', RT_From = '" . $FromTime . "',RT_To = '" . $ToTime . "' ,RType = '" . $Content . "' WHERE id='" . $_GET['idroom'] . "'";
	mysqli_query($mysqli, $sql_modify);
	header('Location:../index.php?quanly=room&query=add');
	//Delete
} else {
	$id = $_GET['idroom'];
	$sql_delete = "DELETE FROM tbl_room WHERE id='" . $id . "'";
	mysqli_query($mysqli, $sql_delete);
	header('Location:../index.php?quanly=room&query=add');
}

?>