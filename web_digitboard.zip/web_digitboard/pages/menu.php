<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Responsive Navbar</title>
	<style>
		.logo {
			height: 50px;
		}
	</style>
</head>

<body>

	<nav class="navbar navbar-expand-lg navbar-light">
		<div class="container">
			<!-- Logo -->
			<a class="navbar-brand" href="index.php">
				<img src="images/KANEKAVN.png" alt="Logo" class="logo">
			</a>

			<!-- Nút toggle -->
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
				aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<!-- Menu -->
			<div class="collapse navbar-collapse fw-bold" id="navbarNav">
				<ul class="navbar-nav me-auto">
					<li class="nav-item"><a class="nav-link" href="index.php?quanly=info&query=info">Info Board</a></li>
					<li class="nav-item"><a class="nav-link" href="index.php?quanly=room&query=add">Room Register</a>
					</li>
					<li class="nav-item"><a class="nav-link" href="index.php?quanly=schedule&query=add">Schedule
							Register</a></li>
					<li class="nav-item"><a class="nav-link" href="index.php?quanly=business&query=add">Business
							Register</a></li>
				</ul>
			</div>
		</div>
	</nav>

	<script src="js/bootstrap.js"></script>
</body>

</html>