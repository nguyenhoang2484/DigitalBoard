<?php
include_once("../admincp/config/config.php");
$sql_sua_business = "SELECT * FROM tbl_business WHERE id = '$_GET[idroom]' LIMIT 1";
$query_sua_business = mysqli_query($mysqli, $sql_sua_business);
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Modify Business Schedule</title>
	<link href="../css/bootstrap.css" rel="stylesheet">
</head>

<body>
	<div class="container mt-1 mb-5">
		<div class="col-10 col-md-8 col-lg-6 col-xl-5">
			<!-- <h3 class="text-center mb-4">Modify Business Schedule</h3> -->
			<form method="POST" action="processbusiness.php?idroom=<?php echo $_GET['idroom'] ?>">
				<div class="table-responsive">
					<table class="table table-bordered table-striped">
						<?php while ($dong = mysqli_fetch_array($query_sua_business)) { ?>
							<thead>
								<tr class="text-center bg-info text-white">
									<td colspan="2" class="fw-bold"
										style="text-align: center;background-color: lightseagreen;">
										UPDATE BUSINESS</td>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><strong>Business</strong></td>
									<td><input type="text" class="form-control" value="<?php echo $dong['B_Name'] ?>"
											name="Name"></td>
								</tr>
								<tr>
									<td><strong>From Date</strong></td>
									<td><input type="date" class="form-control" value="<?php echo $dong['D_From'] ?>"
											name="FromDate"></td>
								</tr>
								<tr>
									<td><strong>To Date</strong></td>
									<td><input type="date" class="form-control" value="<?php echo $dong['D_To'] ?>"
											name="ToDate"></td>
								</tr>
								<tr>
									<td><strong>From Time</strong></td>
									<td><input type="time" class="form-control" value="<?php echo $dong['T_From'] ?>"
											name="FromTime"></td>
								</tr>
								<tr>
									<td><strong>To Time</strong></td>
									<td><input type="time" class="form-control" value="<?php echo $dong['T_To'] ?>"
											name="ToTime"></td>
								</tr>
								<tr>
									<td><strong>Content</strong></td>
									<td><input type="text" class="form-control" value="<?php echo $dong['B_Type'] ?>"
											name="Content"></td>
								</tr>
								<tr>
									<td colspan="2" class="text-center">
										<button type="submit" name="businessupdate" class="btn btn-primary">Update</button>
										<a href="../index.php?quanly=business&query=add" class="btn btn-secondary">Go
											Back</a>
									</td>
								</tr>
							</tbody>
						<?php } ?>
					</table>
				</div>
			</form>
		</div>
		<?php
		$sql_lietke_business = "SELECT * FROM tbl_business ORDER BY B_UpdateTime ASC;";
		$query_lietke_business = mysqli_query($mysqli, $sql_lietke_business);
		$sql_lietke_business_updatetime = "SELECT * FROM tbl_business ORDER BY B_UpdateTime DESC LIMIT 1;";
		$query_lietke_business_updatetime = mysqli_query($mysqli, $sql_lietke_business_updatetime);
		$row_business_updatetime = mysqli_fetch_array($query_lietke_business_updatetime);
		?>
		<div class="mt-3">
			<table class="table-bordered table-striped table-hover table-sm">
				<h3>Recently Business</h3>
				<p>
					<?php
					if ($row_business_updatetime) {
						echo 'Update Time: ' . $row_business_updatetime['B_UpdateTime'];
					} else {
						echo 'No recent updates found.';
					}
					?>
				</p>
				<tr class=" text-center bg-body-secondary">
					<th style="width: 3%;">ID</th>
					<th style="width: 20%;">Name</th>
					<th style="width: 8%;">Date From</th>
					<th style="width: 8%;">Date To</th>
					<th style="width: 8%;">Time From</th>
					<th style="width: 8%;">Time To</th>
					<th style="width: 32%;">Business</th>

				</tr>
				<?php
				$i = 0;
				date_default_timezone_set('Asia/Ho_Chi_Minh'); // Thiết lập múi giờ
				$currentDateTime = date('Y-m-d H:i:s'); // Lấy ngày giờ hiện tại
				while ($row = mysqli_fetch_array($query_lietke_business)) {
					$i++;
					$dateFromTime = $row['D_From'] . ' ' . $row['T_From'];
					$dateToTime = $row['D_To'] . ' ' . $row['T_To'];

					// Kiểm tra điều kiện để xác định màu sắc cho dòng
					$bgColor = '';
					if (!empty($row['B_Name']) && !empty($row['D_From']) && !empty($row['T_From']) && !empty($row['B_Type'])) {
						if ($dateFromTime <= $currentDateTime && $dateToTime >= $currentDateTime) {
							$bgColor = '#ffeb99'; // Light Yellow cho dòng đang diễn ra
						} elseif ($dateToTime >= $currentDateTime) {
							$bgColor = '#b3e0ff'; // Light Blue cho dòng còn hiệu lực
						} else {
							$bgColor = '#ffcccc'; // Light Red cho dòng đã hết hạn
						}
					} else {
						$bgColor = '#d9d9d9'; // Light Gray cho dòng chưa có thông tin
					}
					?>
					<tr style="height: 40px; background-color: <?php echo $bgColor; ?>;">
						<th class="text-center"><?php echo $i ?></th>
						<td style="padding-left: 5px;"><?php echo $row['B_Name'] ?></td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("Y-M-d", strtotime($row['D_From'])); ?>
						</td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("Y-M-d", strtotime($row['D_To'])); ?>
						</td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("H:i", strtotime($row['T_From'])) ?>
						</td>
						<td style="padding-left: 5px; text-align: center;">
							<?php echo date("H:i", strtotime($row['T_To'])) ?>
						</td>
						<td style="padding-left: 5px;"><?php echo $row['B_Type'] ?></td>

					</tr>
					<?php
				}
				?>
			</table>
		</div>
	</div>

	<script src="../js/bootstrap.js"></script>
</body>

</html>