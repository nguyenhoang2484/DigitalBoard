<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="icon" href="images/kaneka.png">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="keywords"
		content="Electro Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
	<!-- Bootstrap css -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="fontawesome/css/all.css" rel="stylesheet">
	<title>KMV - Digital Board</title>
</head>

<body>
	<script src="js/bootstrap.bundle.min.js" defer></script>
	<?php
	//Config
	include("admincp/config/config.php");
	//Menu
	include("pages/menu.php");
	// Module
	if (isset($_GET['quanly']) && $_GET['query']) {
		$tam = $_GET['quanly'];
		$query = $_GET['query'];
	} else {
		$tam = '';
		$query = '';
	}
	if ($tam == 'room' && $query == 'add') {
		include("pages/room.php");
	} elseif ($tam == 'schedule' && $query == 'add') {
		include("pages/schedule.php");
	} elseif ($tam == 'business' && $query == 'add') {
		include("pages/business.php");
	} elseif ($tam == 'room' && $query == 'modify') {
		include("pages/modify.php");
	} elseif ($tam == 'room' && $query == 'view') {
		include("pages/meeting_timeline.php");
	} elseif ($tam == 'schedule' && $query == 'view') {
		include("pages/modify.php");
	} elseif ($tam == 'schedule' && $query == 'modify') {
		include("pages/modifyplan.php");
	} elseif ($tam == 'business' && $query == 'modify') {
		include("pages/modifybusiness.php");
	} else {
		include("pages/main.php");
	}

	//Footer
	include("pages/footer.php");
	//Even process
	include("pages/archive_events.php");
	?>
</body>

</html>